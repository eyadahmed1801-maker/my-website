#include <Wire.h>
#include "MAX30100_PulseOximeter.h"
#include <LiquidCrystal_I2C.h>
#include "DHT.h"
#include <Adafruit_Sensor.h>
#include <Adafruit_MAX30105.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <Adafruit_SSD1306.h>
#include <MPU6050.h>

#define ONE_WIRE_BUS 4
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define DHTPIN 2
#define DHTTYPE DHT11
#define BUZZER 9

#define REPORTING_PERIOD_MS 1000
#define GRAPH_HEIGHT 16
#define GRAPH_WIDTH 100
#define GRAPH_Y 40

// WiFi / MQTT
const char* ssid = "YOUR_SSID";
const char* password = "YOUR_PASS";
const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

Adafruit_MAX30105 particleSensor;
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
MPU6050 mpu;

LiquidCrystal_I2C lcd(0x27, 16, 2);
DHT dht(DHTPIN, DHTTYPE);
PulseOximeter pox;

uint32_t tsLastReport = 0;
unsigned long buzzerMillis = 0;
bool buzzerState = false;

// BPM history for graph
float bpmHistory[GRAPH_WIDTH] = {0};
int graphIndex = 0;

void onBeatDetected() {
  Serial.println("Beat!");
}

void setup() {
  Serial.begin(115200);
  Wire.begin();

  lcd.init();
  lcd.backlight();
  dht.begin();
  pinMode(BUZZER, OUTPUT);

  // Pulse Oximeter
  Serial.print("Initializing pulse oximeter...");
  if (!pox.begin()) {
    Serial.println("FAILED");
    for(;;);
  } else Serial.println("SUCCESS");
  pox.setOnBeatDetectedCallback(onBeatDetected);

  // OLED
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 failed");
  }
  display.clearDisplay();

  // MAX30105
  if (!particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("MAX30105 not found");
    while (1);
  }
  particleSensor.setup();

  // DS18B20
  sensors.begin();

  // MPU6050
  mpu.initialize();

  // WiFi
  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500); Serial.print(".");
  }
  Serial.println(" connected");

  client.setServer(mqtt_server, 1883);
}

void reconnectMQTT() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("ESP32_Client")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      delay(2000);
    }
  }
}

void loop() {
  unsigned long currentMillis = millis();

  pox.update();
  sensors.requestTemperatures();

  // قراءة المستشعرات
  float tempDHT = dht.readTemperature();
  float tempDS18B20 = sensors.getTempCByIndex(0);
  float bpm = pox.getHeartRate();
  float spo2 = pox.getSpO2();
  if (isnan(tempDHT)) tempDHT = 0;
  if (isnan(bpm)) bpm = 0;
  if (isnan(spo2)) spo2 = 0;

  // قراءة MAX30105
  long irValue = particleSensor.getIR();
  long redValue = particleSensor.getRed();

  // قراءة MPU6050
  int16_t ax, ay, az;
  mpu.getAcceleration(&ax, &ay, &az);
  bool fallDetected = (abs(az) > 25000); // يمكن تعديل حسب المعايرة

  // تحديث BPM history
  bpmHistory[graphIndex] = bpm;
  graphIndex = (graphIndex + 1) % GRAPH_WIDTH;

  // OLED display
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0,0);
  display.printf("Temp:%.1fC SpO2:%.0f%%", tempDHT, spo2);
  display.setCursor(0,10);
  display.printf("Fall: %d", fallDetected);

  // رسم مخطط BPM
  display.drawRect(0, GRAPH_Y-1, GRAPH_WIDTH, GRAPH_HEIGHT, WHITE);
  for(int i=0; i<GRAPH_WIDTH; i++){
    int index = (graphIndex + i) % GRAPH_WIDTH;
    int y = GRAPH_Y + GRAPH_HEIGHT - (bpmHistory[index]/2); // التحجيم
    if(y < GRAPH_Y) y = GRAPH_Y;
    if(y > GRAPH_Y + GRAPH_HEIGHT) y = GRAPH_Y + GRAPH_HEIGHT;
    display.drawPixel(i, y, WHITE);
  }

  // رسم شريط SpO2
  int spo2Bar = map((int)spo2, 0, 100, 0, GRAPH_HEIGHT);
  display.fillRect(110, GRAPH_Y, 10, -spo2Bar, WHITE);

  display.display();

  // LCD display
  if (currentMillis - tsLastReport > REPORTING_PERIOD_MS) {
    tsLastReport = currentMillis;
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.printf("Temp:%.1fC", tempDHT);
    lcd.setCursor(0,1);
    lcd.printf("HR:%.0f  SpO2:%.0f", bpm, spo2);

    // Buzzer alert
    if (bpm < 50 || bpm > 120 || spo2 < 90 || tempDHT > 38) {
      buzzerState = true;
      buzzerMillis = currentMillis;
    }
  }

  // Buzzer logic
  if (buzzerState) {
    if ((currentMillis - buzzerMillis) < 500) {
      digitalWrite(BUZZER, HIGH);
    } else if ((currentMillis - buzzerMillis) < 1000) {
      digitalWrite(BUZZER, LOW);
    } else {
      buzzerMillis = currentMillis;
    }
  }

  // MQTT
  if (!client.connected()) reconnectMQTT();
  client.loop();

  String payload = "{\"tempDHT\":" + String(tempDHT) +
                   ",\"tempDS18B20\":" + String(tempDS18B20) +
                   ",\"bpm\":" + String(bpm) +
                   ",\"spo2\":" + String(spo2) +
                   ",\"ir\":" + String(irValue) +
                   ",\"red\":" + String(redValue) +
                   ",\"fall\":" + String(fallDetected) + "}";
  client.publish("home/health/device1", payload.c_str());
}
