/* ==========================================================================
   EYAD AHMED — PORTFOLIO JS
   Loader, particles, typing effect, theme + language switching,
   scroll reveal, magnetic buttons, cursor glow, counters, contact form.
   ========================================================================== */

(function () {
  'use strict';

  /* ------------------------------------------------------------------ */
  /* 1. TRANSLATIONS                                                     */
  /* ------------------------------------------------------------------ */
  const translations = {
    en: {
      "loader.text": "booting interface",
      "nav.home": "Home", "nav.about": "About", "nav.skills": "Skills",
      "nav.projects": "Projects", "nav.services": "Services", "nav.experience": "Experience",
      "nav.contact": "Contact", "nav.hire": "Hire Me",
      "hero.eyebrow": "Available for opportunities",
      "hero.hi": "Hi, I'm",
      "hero.iam": "I'm a",
      "hero.desc": "I craft fast, elegant interfaces on the web and bring ideas to life with circuits and code — merging front-end design with embedded electronics, from Egypt to the world.",
      "hero.cv": "Download CV",
      "hero.contact": "Contact Me",
      "hero.scroll": "Scroll",
      "about.eyebrow": "About Me", "about.title": "The person behind the code",
      "about.p1": "I'm Eyad Ahmed, a front-end developer and Arduino enthusiast from Egypt. I live at the intersection of pixels and circuits — designing interfaces that feel effortless, and building hardware that reacts to the real world.",
      "about.p2": "My passion for technology started with curiosity: taking things apart, wiring my first LED, then falling in love with the way a well-crafted interface can make complex ideas feel simple. That same curiosity now drives every project I build.",
      "about.p3": "My goal is to keep growing as a full-stack creator of digital and physical products — shipping interfaces that feel premium, and smart devices that quietly make life easier.",
      "about.stat1": "Projects Built", "about.stat2": "Tech Stacks", "about.stat3": "Years Learning", "about.stat4": "Dedication",
      "about.journey": "Learning Journey",
      "about.t1title": "First lines of HTML & CSS", "about.t1desc": "Discovered web development and built my first static pages.",
      "about.t2title": "JavaScript & interactivity", "about.t2desc": "Learned to bring interfaces to life with logic and animation.",
      "about.t3title": "Arduino & electronics", "about.t3desc": "Started wiring sensors and microcontrollers, merging hardware with code.",
      "about.t4title": "Python, Flask & IoT", "about.t4desc": "Built smart systems that connect embedded devices to the web.",
      "about.t5title": "Real-world projects", "about.t5desc": "Shipping polished products — from irrigation systems to Discord bots.",
      "skills.eyebrow": "Skills", "skills.title": "Tools I build with",
      "skills.sub": "A blend of front-end craftsmanship and embedded engineering.",
      "skills.programming": "Programming", "skills.frameworks": "Frameworks & Libraries", "skills.tools": "Tools",
      "projects.eyebrow": "Projects", "projects.title": "Selected work",
      "projects.sub": "A mix of software, hardware, and everything in between.",
      "projects.code": "Code", "projects.demo": "Live Demo",
      "proj.aqua.title": "AquaLeaf Smart Irrigation System",
      "proj.aqua.desc": "An Arduino-powered irrigation system that reads soil moisture in real time and automatically waters plants, with a live dashboard to monitor levels remotely.",
      "proj.robot.title": "Smart Farming Robot",
      "proj.robot.desc": "An autonomous rover concept that navigates fields, detects obstacles, and collects environmental data to support small-scale precision farming.",
      "proj.bot.title": "Discord Bot",
      "proj.bot.desc": "A feature-rich Discord bot with moderation tools, custom commands, and utilities built in Python to help manage active communities.",
      "proj.folio.title": "Personal Portfolio",
      "proj.folio.desc": "This very site — a premium, glassmorphic portfolio with smooth animations, dark/light modes, and bilingual support, built from scratch.",
      "proj.future.title": "Future Projects",
      "proj.future.desc": "More experiments in AI-assisted interfaces and connected hardware are on the way — always exploring where code meets the physical world.",
      "proj.future.tag": "Coming Soon",
      "services.eyebrow": "Services", "services.title": "How I can help",
      "services.s1title": "Front-End Development", "services.s1desc": "Building fast, accessible, pixel-perfect interfaces with modern frameworks and clean code.",
      "services.s2title": "Responsive Website Design", "services.s2desc": "Designing layouts that look and feel premium on every screen, from mobile to desktop.",
      "services.s3title": "Arduino Projects", "services.s3desc": "Designing and building custom electronics — from sensors and automation to full IoT systems.",
      "services.s4title": "UI/UX Design", "services.s4desc": "Crafting intuitive user flows and modern interfaces that balance beauty with usability.",
      "services.s5title": "Discord Bot Development", "services.s5desc": "Building custom bots with moderation, automation, and community features tailored to your server.",
      "experience.eyebrow": "Experience", "experience.title": "My path so far",
      "experience.e1title": "Started learning web development", "experience.e1desc": "Began with HTML, CSS and JavaScript fundamentals, building small static projects.",
      "experience.e2title": "Dove into Arduino & electronics", "experience.e2desc": "Learned circuits, sensors and microcontrollers — building my first automated devices.",
      "experience.e3title": "Built AquaLeaf & the Farming Robot", "experience.e3desc": "Combined hardware and software skills into two full IoT-driven projects.",
      "experience.e4title": "Expanded into Python & bots", "experience.e4desc": "Developed a Discord bot and backend services with Python and Flask.",
      "experience.e5title": "Refined UI/UX & design craft", "experience.e5desc": "Focused on premium interface design, launching this portfolio as a showcase.",
      "certs.eyebrow": "Certificates", "certs.title": "Learning milestones",
      "certs.c1": "Front-End Web Development", "certs.c1issuer": "Online Certification",
      "certs.c2": "Python Programming", "certs.c2issuer": "Online Certification",
      "certs.c3": "Embedded Systems with Arduino", "certs.c3issuer": "Online Certification",
      "certs.c4": "UI/UX Design Fundamentals", "certs.c4issuer": "Online Certification",
      "testi.eyebrow": "Testimonials", "testi.title": "What people say",
      "testi.t1": "Eyad turned our idea into a smart irrigation prototype faster than we expected — clean code, and it just worked.",
      "testi.t1name": "Mohamed H.", "testi.t1role": "Project Collaborator",
      "testi.t2": "Great attention to detail on the front-end. The interface felt premium and every interaction was smooth.",
      "testi.t2name": "Sara A.", "testi.t2role": "Client",
      "testi.t3": "His Discord bot made managing our community effortless. Reliable, fast, and easy to customize.",
      "testi.t3name": "Omar K.", "testi.t3role": "Community Manager",
      "contact.eyebrow": "Contact", "contact.title": "Let's build something together",
      "contact.sub": "Have a project in mind? I'd love to hear about it.",
      "contact.name": "Name", "contact.email": "Email", "contact.message": "Message", "contact.send": "Send Message",
      "contact.note": "This form is a demo — connect it to your email service to receive messages.",
      "contact.emailLabel": "Email",
      "footer.tagline": "Front-End Developer & Arduino Developer, crafting interfaces and circuits from Egypt.",
      "footer.quick": "Quick Links", "footer.follow": "Follow",
      "footer.copyright": "© 2026 Eyad Ahmed. All rights reserved.",
      "footer.credit": "Designed & Developed by Eyad Ahmed"
    },
    ar: {
      "loader.text": "جاري تحميل الواجهة",
      "nav.home": "الرئيسية", "nav.about": "عني", "nav.skills": "المهارات",
      "nav.projects": "المشاريع", "nav.services": "الخدمات", "nav.experience": "الخبرة",
      "nav.contact": "تواصل", "nav.hire": "وظفني",
      "hero.eyebrow": "متاح لفرص جديدة",
      "hero.hi": "أهلاً، أنا",
      "hero.iam": "أنا",
      "hero.desc": "أصمم واجهات ويب سريعة وأنيقة، وأحوّل الأفكار إلى واقع عبر الدوائر الإلكترونية والبرمجة — مزج بين تصميم الواجهات الأمامية والإلكترونيات المدمجة، من مصر إلى العالم.",
      "hero.cv": "تحميل السيرة الذاتية",
      "hero.contact": "تواصل معي",
      "hero.scroll": "مرر للأسفل",
      "about.eyebrow": "عني", "about.title": "الشخص وراء الكود",
      "about.p1": "أنا إياد أحمد، مطوّر واجهات أمامية وهاوٍ لتقنية أردوينو من مصر. أعيش عند تقاطع البكسل والدوائر الإلكترونية — أصمم واجهات سلسة، وأبني أجهزة تتفاعل مع العالم الحقيقي.",
      "about.p2": "بدأ شغفي بالتكنولوجيا بالفضول: تفكيك الأجهزة، توصيل أول LED لي، ثم الوقوع في حب الطريقة التي تجعل بها الواجهة المصممة جيدًا الأفكار المعقدة تبدو بسيطة. هذا الفضول نفسه يقود كل مشروع أبنيه الآن.",
      "about.p3": "هدفي هو الاستمرار في النمو كمطوّر متكامل للمنتجات الرقمية والمادية — بواجهات تبدو فاخرة، وأجهزة ذكية تسهّل الحياة بهدوء.",
      "about.stat1": "مشروع منجز", "about.stat2": "تقنيات مستخدمة", "about.stat3": "سنوات تعلّم", "about.stat4": "التزام",
      "about.journey": "رحلة التعلّم",
      "about.t1title": "أول أسطر HTML و CSS", "about.t1desc": "اكتشفت تطوير الويب وبنيت أول صفحاتي الثابتة.",
      "about.t2title": "جافاسكريبت والتفاعل", "about.t2desc": "تعلمت كيف أُحيي الواجهات بالمنطق والحركة.",
      "about.t3title": "أردوينو والإلكترونيات", "about.t3desc": "بدأت بتوصيل الحساسات والمتحكمات، ودمج الهاردوير بالكود.",
      "about.t4title": "بايثون، Flask وإنترنت الأشياء", "about.t4desc": "بنيت أنظمة ذكية تربط الأجهزة المدمجة بالويب.",
      "about.t5title": "مشاريع حقيقية", "about.t5desc": "إطلاق منتجات متكاملة — من أنظمة الري إلى بوتات ديسكورد.",
      "skills.eyebrow": "المهارات", "skills.title": "الأدوات التي أستخدمها",
      "skills.sub": "مزيج من حرفية الواجهات الأمامية وهندسة الأنظمة المدمجة.",
      "skills.programming": "البرمجة", "skills.frameworks": "أطر وعمل مكتبات", "skills.tools": "الأدوات",
      "projects.eyebrow": "المشاريع", "projects.title": "أعمال مختارة",
      "projects.sub": "مزيج من البرمجيات والهاردوير وكل ما بينهما.",
      "projects.code": "الكود", "projects.demo": "عرض حي",
      "proj.aqua.title": "نظام الري الذكي AquaLeaf",
      "proj.aqua.desc": "نظام ري يعمل بالأردوينو يقرأ رطوبة التربة لحظيًا ويسقي النباتات تلقائيًا، مع لوحة تحكم لمتابعة المستويات عن بُعد.",
      "proj.robot.title": "روبوت الزراعة الذكي",
      "proj.robot.desc": "مفهوم مركبة ذاتية القيادة تتنقل في الحقول، تكتشف العوائق وتجمع بيانات بيئية لدعم الزراعة الدقيقة.",
      "proj.bot.title": "بوت ديسكورد",
      "proj.bot.desc": "بوت ديسكورد غني بالميزات مع أدوات إشراف وأوامر مخصصة، مبني بلغة بايثون لإدارة المجتمعات النشطة.",
      "proj.folio.title": "الموقع الشخصي",
      "proj.folio.desc": "هذا الموقع بالذات — بورتفوليو فاخر بتأثير الزجاج، حركات سلسة، وضع ليلي/نهاري، ودعم لغتين.",
      "proj.future.title": "مشاريع قادمة",
      "proj.future.desc": "المزيد من التجارب في واجهات مدعومة بالذكاء الاصطناعي وأجهزة متصلة قادمة قريبًا.",
      "proj.future.tag": "قريبًا",
      "services.eyebrow": "الخدمات", "services.title": "كيف يمكنني المساعدة",
      "services.s1title": "تطوير واجهات أمامية", "services.s1desc": "بناء واجهات سريعة ودقيقة البكسل بأطر عمل حديثة وكود نظيف.",
      "services.s2title": "تصميم مواقع متجاوبة", "services.s2desc": "تصميم تخطيطات تبدو فاخرة على كل الشاشات، من الموبايل إلى الديسكتوب.",
      "services.s3title": "مشاريع أردوينو", "services.s3desc": "تصميم وبناء إلكترونيات مخصصة — من الحساسات إلى أنظمة إنترنت الأشياء الكاملة.",
      "services.s4title": "تصميم UI/UX", "services.s4desc": "صياغة تدفقات مستخدم بديهية وواجهات حديثة توازن بين الجمال وسهولة الاستخدام.",
      "services.s5title": "تطوير بوتات ديسكورد", "services.s5desc": "بناء بوتات مخصصة بميزات إشراف وأتمتة تناسب سيرفرك.",
      "experience.eyebrow": "الخبرة", "experience.title": "مسيرتي حتى الآن",
      "experience.e1title": "بدأت تعلّم تطوير الويب", "experience.e1desc": "بدأت بأساسيات HTML وCSS وJavaScript، وبنيت مشاريع صغيرة ثابتة.",
      "experience.e2title": "دخلت عالم الأردوينو والإلكترونيات", "experience.e2desc": "تعلمت الدوائر والحساسات والمتحكمات — وبنيت أول أجهزتي الآلية.",
      "experience.e3title": "بنيت AquaLeaf وروبوت الزراعة", "experience.e3desc": "دمجت مهارات الهاردوير والسوفتوير في مشروعين كاملين مدعومين بإنترنت الأشياء.",
      "experience.e4title": "توسعت في بايثون والبوتات", "experience.e4desc": "طوّرت بوت ديسكورد وخدمات خلفية باستخدام Python وFlask.",
      "experience.e5title": "طوّرت حرفية تصميم UI/UX", "experience.e5desc": "ركزت على تصميم واجهات فاخرة، وأطلقت هذا الموقع كعرض تقديمي.",
      "certs.eyebrow": "الشهادات", "certs.title": "محطات التعلّم",
      "certs.c1": "تطوير الواجهات الأمامية", "certs.c1issuer": "شهادة عبر الإنترنت",
      "certs.c2": "برمجة بايثون", "certs.c2issuer": "شهادة عبر الإنترنت",
      "certs.c3": "الأنظمة المدمجة مع أردوينو", "certs.c3issuer": "شهادة عبر الإنترنت",
      "certs.c4": "أساسيات تصميم UI/UX", "certs.c4issuer": "شهادة عبر الإنترنت",
      "testi.eyebrow": "آراء", "testi.title": "ماذا يقول الآخرون",
      "testi.t1": "حوّل إياد فكرتنا إلى نموذج ري ذكي أسرع مما توقعنا — كود نظيف واشتغل من أول مرة.",
      "testi.t1name": "محمد ح.", "testi.t1role": "شريك مشروع",
      "testi.t2": "اهتمام كبير بالتفاصيل في الواجهة الأمامية. شعرت الواجهة بأنها فاخرة وكل تفاعل كان سلسًا.",
      "testi.t2name": "سارة أ.", "testi.t2role": "عميلة",
      "testi.t3": "بوت الديسكورد الخاص به سهّل إدارة مجتمعنا. موثوق، سريع، وسهل التخصيص.",
      "testi.t3name": "عمر ك.", "testi.t3role": "مدير مجتمع",
      "contact.eyebrow": "تواصل", "contact.title": "لنبني شيئًا معًا",
      "contact.sub": "لديك مشروع في ذهنك؟ يسعدني أن أسمع عنه.",
      "contact.name": "الاسم", "contact.email": "البريد الإلكتروني", "contact.message": "الرسالة", "contact.send": "إرسال الرسالة",
      "contact.note": "هذا النموذج تجريبي — قم بربطه بخدمة بريدك الإلكتروني لاستقبال الرسائل.",
      "contact.emailLabel": "البريد الإلكتروني",
      "footer.tagline": "مطوّر واجهات أمامية ومطوّر أردوينو، أصنع الواجهات والدوائر من مصر.",
      "footer.quick": "روابط سريعة", "footer.follow": "تابعني",
      "footer.copyright": "© 2026 إياد أحمد. جميع الحقوق محفوظة.",
      "footer.credit": "تصميم وتطوير إياد أحمد"
    }
  };

  const typedRoles = {
    en: ["Front-End Developer", "Arduino Developer", "UI Designer", "Tech Enthusiast"],
    ar: ["مطوّر واجهات أمامية", "مطوّر أردوينو", "مصمم واجهات", "شغوف بالتقنية"]
  };

  let currentLang = localStorage.getItem('ea-lang') || 'en';

  function applyLanguage(lang) {
    currentLang = lang;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    const dict = translations[lang];
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) el.textContent = dict[key];
    });
    const label = document.getElementById('langLabel');
    if (label) label.textContent = lang === 'en' ? 'EN' : 'AR';
    localStorage.setItem('ea-lang', lang);
    restartTyping();
  }

  /* ------------------------------------------------------------------ */
  /* 2. LOADER                                                            */
  /* ------------------------------------------------------------------ */
  function initLoader() {
    const loader = document.getElementById('loader');
    const bar = document.getElementById('loaderProgress');
    let p = 0;
    const timer = setInterval(() => {
      p += Math.random() * 18;
      if (p >= 100) { p = 100; clearInterval(timer); }
      bar.style.width = p + '%';
    }, 140);

    window.addEventListener('load', () => {
      setTimeout(() => {
        bar.style.width = '100%';
        setTimeout(() => {
          loader.classList.add('hidden');
          document.body.classList.remove('no-scroll');
          revealOnLoad();
        }, 400);
      }, 500);
    });
    document.body.classList.add('no-scroll');
    // Fallback in case load event already fired
    setTimeout(() => { if (!loader.classList.contains('hidden')) window.dispatchEvent(new Event('load')); }, 3500);
  }

  function revealOnLoad() {
    document.querySelectorAll('.hero [data-reveal]').forEach(el => el.classList.add('in-view'));
  }

  /* ------------------------------------------------------------------ */
  /* 3. TYPING EFFECT                                                     */
  /* ------------------------------------------------------------------ */
  let typingTimeout;
  function restartTyping() {
    clearTimeout(typingTimeout);
    const el = document.getElementById('typedText');
    if (!el) return;
    const roles = typedRoles[currentLang];
    let roleIndex = 0, charIndex = 0, deleting = false;

    function tick() {
      const word = roles[roleIndex];
      if (!deleting) {
        charIndex++;
        el.textContent = word.slice(0, charIndex);
        if (charIndex === word.length) {
          deleting = true;
          typingTimeout = setTimeout(tick, 1600);
          return;
        }
        typingTimeout = setTimeout(tick, 85);
      } else {
        charIndex--;
        el.textContent = word.slice(0, charIndex);
        if (charIndex === 0) {
          deleting = false;
          roleIndex = (roleIndex + 1) % roles.length;
          typingTimeout = setTimeout(tick, 400);
          return;
        }
        typingTimeout = setTimeout(tick, 40);
      }
    }
    tick();
  }

  /* ------------------------------------------------------------------ */
  /* 4. PARTICLES CANVAS (lightweight, dependency-free)                  */
  /* ------------------------------------------------------------------ */
  function initParticles() {
    const canvas = document.getElementById('particles');
    const ctx = canvas.getContext('2d');
    let w, h, particles = [];
    const colors = ['#3B82F6', '#06B6D4', '#8B5CF6'];
    const COUNT = window.innerWidth < 768 ? 40 : 85;

    function resize() {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    }
    function makeParticles() {
      particles = Array.from({ length: COUNT }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.6 + 0.6,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        c: colors[Math.floor(Math.random() * colors.length)],
        a: Math.random() * 0.5 + 0.2
      }));
    }
    function step() {
      ctx.clearRect(0, 0, w, h);
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = w; if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h; if (p.y > h) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.c;
        ctx.globalAlpha = p.a;
        ctx.fill();
      });
      ctx.globalAlpha = 1;
      // connecting lines for nearby particles
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 110) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = 'rgba(59,130,246,' + (0.12 * (1 - dist / 110)) + ')';
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(step);
    }
    resize(); makeParticles();
    window.addEventListener('resize', () => { resize(); makeParticles(); });
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      requestAnimationFrame(step);
    }
  }

  /* ------------------------------------------------------------------ */
  /* 5. NAV: scroll state, mobile menu, active link                      */
  /* ------------------------------------------------------------------ */
  function initNav() {
    const navbar = document.getElementById('navbar');
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    const links = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });

    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
      navToggle.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      navLinks.classList.remove('open');
      navToggle.classList.remove('open');
    }));

    const sections = Array.from(links).map(l => document.querySelector(l.getAttribute('href')));
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          links.forEach(l => l.classList.remove('active'));
          const active = document.querySelector('.nav-link[href="#' + entry.target.id + '"]');
          if (active) active.classList.add('active');
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach(s => s && io.observe(s));
  }

  /* ------------------------------------------------------------------ */
  /* 6. THEME TOGGLE                                                     */
  /* ------------------------------------------------------------------ */
  function initTheme() {
    const saved = localStorage.getItem('ea-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', saved);
    document.getElementById('themeToggle').addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('ea-theme', next);
    });
  }

  /* ------------------------------------------------------------------ */
  /* 7. LANGUAGE TOGGLE                                                   */
  /* ------------------------------------------------------------------ */
  function initLang() {
    applyLanguage(currentLang);
    document.getElementById('langToggle').addEventListener('click', () => {
      applyLanguage(currentLang === 'en' ? 'ar' : 'en');
    });
  }

  /* ------------------------------------------------------------------ */
  /* 8. SCROLL REVEAL                                                     */
  /* ------------------------------------------------------------------ */
  function initReveal() {
    const targets = document.querySelectorAll('[data-reveal], .skill-card, .stat-card');
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry, idx) => {
        if (entry.isIntersecting) {
          entry.target.style.setProperty('--i', idx % 6);
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    targets.forEach(t => io.observe(t));
  }

  /* ------------------------------------------------------------------ */
  /* 9. ANIMATED COUNTERS                                                 */
  /* ------------------------------------------------------------------ */
  function initCounters() {
    const counters = document.querySelectorAll('.stat-number');
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = parseInt(el.getAttribute('data-target'), 10);
        let current = 0;
        const duration = 1400;
        const start = performance.now();
        function tick(now) {
          const progress = Math.min((now - start) / duration, 1);
          current = Math.floor(progress * target);
          el.textContent = current;
          if (progress < 1) requestAnimationFrame(tick);
          else el.textContent = target;
        }
        requestAnimationFrame(tick);
        io.unobserve(el);
      });
    }, { threshold: 0.5 });
    counters.forEach(c => io.observe(c));
  }

  /* ------------------------------------------------------------------ */
  /* 10. CURSOR GLOW + MAGNETIC BUTTONS                                   */
  /* ------------------------------------------------------------------ */
  function initCursor() {
    const glow = document.getElementById('cursorGlow');
    if (window.matchMedia('(hover: none)').matches) return;
    window.addEventListener('mousemove', (e) => {
      glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%, -50%)`;
    });
  }

  function initMagnetic() {
    if (window.matchMedia('(hover: none)').matches) return;
    document.querySelectorAll('.magnetic, .magnetic-soft').forEach(el => {
      const strength = el.classList.contains('magnetic-soft') ? 14 : 22;
      el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        el.style.transform = `translate(${(x / rect.width) * strength}px, ${(y / rect.height) * strength}px)`;
      });
      el.addEventListener('mouseleave', () => { el.style.transform = ''; });
    });
  }

  /* ------------------------------------------------------------------ */
  /* 11. SCROLL PROGRESS + BACK TO TOP                                    */
  /* ------------------------------------------------------------------ */
  function initScrollUtils() {
    const bar = document.getElementById('scrollProgressBar');
    const backBtn = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
      const scrollTop = window.scrollY;
      const height = document.documentElement.scrollHeight - window.innerHeight;
      const pct = height > 0 ? (scrollTop / height) * 100 : 0;
      bar.style.width = pct + '%';
      backBtn.classList.toggle('visible', scrollTop > 500);
    }, { passive: true });
    backBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  /* ------------------------------------------------------------------ */
  /* 12. CONTACT FORM (demo submit)                                       */
  /* ------------------------------------------------------------------ */
  function initContactForm() {
    const form = document.getElementById('contactForm');
    const note = document.getElementById('formNote');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = currentLang === 'ar'
        ? 'شكرًا! تم استلام رسالتك التجريبية (لم يتم إرسالها فعليًا).'
        : "Thanks! Your message was captured locally (this demo form doesn't send email yet).";
      note.textContent = msg;
      note.classList.add('success');
      form.reset();
    });
  }

  /* ------------------------------------------------------------------ */
  /* INIT                                                                 */
  /* ------------------------------------------------------------------ */
  document.addEventListener('DOMContentLoaded', () => {
    initLoader();
    initParticles();
    initNav();
    initTheme();
    initLang();
    initReveal();
    initCounters();
    initCursor();
    initMagnetic();
    initScrollUtils();
    initContactForm();
  });
})();
